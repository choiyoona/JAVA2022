package Pkg.Commons;

public enum Survive {
	die, alive
}

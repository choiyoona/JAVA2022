package Pkg.Commons;

public interface IZerg {
	public UnitKind unitKind = UnitKind.Zerg;
	
}

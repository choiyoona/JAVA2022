package Pkg.Commons;

public interface IProtoss {
	public UnitKind unitKind = UnitKind.Protoss;
	
	
}

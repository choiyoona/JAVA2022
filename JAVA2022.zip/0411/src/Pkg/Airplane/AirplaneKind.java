package Pkg.Airplane;

public enum AirplaneKind {
	Mutal, Corsair
}

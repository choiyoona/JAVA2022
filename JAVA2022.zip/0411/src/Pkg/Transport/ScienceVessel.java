package Pkg.Transport;

import Pkg.Commons.IProtoss;

public class ScienceVessel extends Transport implements IProtoss {

	
	public ScienceVessel() {
		super();
	}
	public ScienceVessel(int health, int pickupNum) {
		super(health, pickupNum);
	}
	
	
	
	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pickup() {
		// TODO Auto-generated method stub
		
	}
	
}

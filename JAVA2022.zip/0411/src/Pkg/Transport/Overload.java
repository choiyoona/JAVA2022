package Pkg.Transport;

public class Overload extends Transport{

	public Overload() {
		super();
	}
	public Overload(int health, int pickupNum) {
		super(health, pickupNum);
	}
	
	@Override
	public void fly() {
		
		
	}

	@Override
	public void pickup() {
		// TODO Auto-generated method stub
		
	}
	
	public void observe() {
		
	}
	
	
	
}

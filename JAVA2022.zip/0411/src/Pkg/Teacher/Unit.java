package Pkg.Teacher;

public abstract class Unit {
	protected String name;
	public abstract void attack();
}

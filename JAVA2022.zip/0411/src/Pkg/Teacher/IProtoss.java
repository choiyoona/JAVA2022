package Pkg.Teacher;

public interface IProtoss {
	
}

package Pkg.Teacher;

public class Zergling extends Unit{
	public void attack() {
		
	}
}

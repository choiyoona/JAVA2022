package Pkg.Commons;

public interface IProtoss {
	public UnitKind unitkind = UnitKind.Protoss;
}

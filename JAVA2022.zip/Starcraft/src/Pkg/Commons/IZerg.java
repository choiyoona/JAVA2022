package Pkg.Commons;

public interface IZerg {
	public UnitKind unitkind = UnitKind.Zerg;
}

package Pkg.Commons;

public enum Death {
	die, alive
}

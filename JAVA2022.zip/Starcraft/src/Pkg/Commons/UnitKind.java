package Pkg.Commons;

public enum UnitKind {
	Zerg, Protoss, Default;
}

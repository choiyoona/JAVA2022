package Pkg.Commons;

public interface IUnit {
	public UnitKind unitKind = UnitKind.Default;

}

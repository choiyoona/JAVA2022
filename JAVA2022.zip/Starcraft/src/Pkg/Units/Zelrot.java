package Pkg.Units;

public class Zelrot extends Unit {
	
	
	
	
	//메소드
	@Override
	public void attack(Unit attackUnit, Unit receiveUnit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void upgrade(Unit attackUnit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void die(Unit dieUnit) {
		// TODO Auto-generated method stub
		
	}

}

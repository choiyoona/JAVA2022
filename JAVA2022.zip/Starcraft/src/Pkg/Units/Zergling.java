package Pkg.Units;

import Pkg.Commons.IUnit;

public class Zergling extends Unit implements IUnit{
	
	public Zergling() {
		
	}
	
	
	//메소드
	@Override
	public void attack(Unit attackUnit, Unit receiveUnit) {
		
	}

	@Override
	public void upgrade(Unit attackUnit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void die(Unit dieUnit) {
		// TODO Auto-generated method stub
		
	}

}
